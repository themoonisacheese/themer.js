This is themer.js, a tool for generating custom themes for discord.

It requires:

-node.js
https://nodejs.org/en/
-BetterDiscord
https://betterdiscord.net/home/

To use, run 
themer.bat
Or open a console and run:
node themer.js